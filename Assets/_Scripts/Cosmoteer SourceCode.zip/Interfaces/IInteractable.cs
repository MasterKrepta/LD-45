﻿using UnityEngine;

public interface  IInteractable
{
    void Use();
    void Pickup(Transform hand);
}
